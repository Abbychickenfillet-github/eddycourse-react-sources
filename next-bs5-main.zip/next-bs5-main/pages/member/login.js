import React from 'react'
import LoginForm from '@/components/member/login-form'

export default function Login() {
  return <LoginForm />
}
