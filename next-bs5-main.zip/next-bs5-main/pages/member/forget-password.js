import React from 'react'
import ForgetPasswordForm from '@/components/member/forget-password-form'

export default function ForgetPassword() {
  return <ForgetPasswordForm />
}
