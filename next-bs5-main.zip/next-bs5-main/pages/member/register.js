import React from 'react'
import RegisterForm from '@/components/member/register-form'

export default function Register() {
  return <RegisterForm />
}
