export default function Cancel() {
  return (
    <>
      <h1>已取消付款</h1>
    </>
  )
}
