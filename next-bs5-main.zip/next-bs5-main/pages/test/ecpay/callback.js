import React from 'react'

export default function ECPayCallback() {
  return (
    <>
      <h1>已完成付款</h1>
    </>
  )
}
