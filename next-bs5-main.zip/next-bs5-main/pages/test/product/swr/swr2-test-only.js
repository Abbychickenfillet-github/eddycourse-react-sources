import React from 'react'
import PageLoadMore from '@/components/product-test/swr-page-loadmore'

export default function SWR2() {
  return (
    <>
      <PageLoadMore />
    </>
  )
}
