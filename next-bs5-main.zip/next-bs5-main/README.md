# next-bs5

## 版本

v1.2

## 說明

next.js + bootstrap5 boilerplates

