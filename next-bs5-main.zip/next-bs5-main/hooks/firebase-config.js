// 這裡貼上從firebase專案設定中，網頁應用程式整合的設定值
const firebaseConfig = {
  apiKey: 'AIzaSyBsIeIzXTdZk4RPiwmuHVi2n27zQOPRjwU',
  authDomain: 'react-test-e84f6.firebaseapp.com',
  projectId: 'react-test-e84f6',
  storageBucket: 'react-test-e84f6.appspot.com',
  messagingSenderId: '1077454373020',
  appId: '1:1077454373020:web:807add77fcd4858fcc2d59',
}

export { firebaseConfig }
