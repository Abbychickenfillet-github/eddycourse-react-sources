import React from 'react'

export default function Footer() {
  return (
    <>
      <footer className="pt-5 my-5 text-body-secondary border-top">
        Created by the Bootstrap team &middot; &copy; 2023
      </footer>
    </>
  )
}
