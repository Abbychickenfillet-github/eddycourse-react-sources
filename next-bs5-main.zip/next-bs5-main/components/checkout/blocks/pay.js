import React from 'react'

export default function Pay() {
  return <div>Pay</div>
}
