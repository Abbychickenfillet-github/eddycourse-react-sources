import React from 'react'

export default function Ship() {
  return <div>Ship</div>
}
