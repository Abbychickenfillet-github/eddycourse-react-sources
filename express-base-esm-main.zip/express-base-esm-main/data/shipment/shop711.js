const reqBody = {
  storeid: '993041',
  storename: '松高門市',
  storeaddress: '台北市信義區基隆路一段141號1樓',
  outside: '0',
  ship: '1111111',
  TempVar: ''
}